#pragma once
#include <string>
struct ButtonData
{
	std::string fileName;
	unsigned textureID;
};
